<?php 
if(!array_key_exists('P', $_GET) || empty($_GET['P'])){
    include_once 'main.php';
}
else{
    switch ($_GET['P']) {

        case 'register': include_once 'register.php'; break;
        case 'logout': session_unset(); session_destroy(); header('Location: index.php'); break;
        case 'create': include_once 'create.php'; break;
        case 'find' : include_once 'find.php'; break;
        case 'job' : include_once 'job.php'; break;
        default: include_once 'main.php'; break;
        
    }
}

?>