
<?php session_start(); ?>
<?php include_once 'config/init.php'; ?>
<?php include_once 'config/config.php'; ?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
		<link rel="stylesheet" href="css/style.css">
		<?php include_once 'nav.php'; ?>
	</head>
	<body>
		<?php include_once 'routing.php'; ?>
	</body>
</html>