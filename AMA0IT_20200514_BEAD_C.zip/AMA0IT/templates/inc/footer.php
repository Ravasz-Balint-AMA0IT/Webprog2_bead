			<footer class="footer">
        <p>&copy; Ravasz Bálint AMA0IT</p>
      </footer>

    </div> 
		</body>
</html>